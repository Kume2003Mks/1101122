package com.example.sensor.ui;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sensor.R;
import com.example.sensor.databinding.FragmentBlankBinding;
import com.example.sensor.databinding.FragmentDashboardBinding;

public class BlankFragment extends Fragment implements SensorEventListener {

    private FragmentBlankBinding binding;
    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding = FragmentBlankBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        SensorManager sensorManager = (SensorManager) getActivity().getSystemService(Context.SENSOR_SERVICE);

        if(sensorManager != null){
            Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
            if (accelerometer != null){
                sensorManager.registerListener(this,accelerometer,SensorManager.SENSOR_DELAY_NORMAL);
            }
        } else {
            Toast.makeText(getContext(), "No Sensor", Toast.LENGTH_SHORT).show();
        }

        view = root;

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD){
            TextView textView = view.findViewById(R.id.Mg1);
            String ss = String.format("X: %s\nY: %s\nZ: %s", event.values[0], event.values[1], event.values[2]);
            textView.setText(ss);
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}