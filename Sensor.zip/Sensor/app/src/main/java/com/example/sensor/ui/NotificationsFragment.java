package com.example.sensor.ui;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.sensor.R;
import com.example.sensor.databinding.FragmentNotificationsBinding;


public class NotificationsFragment extends Fragment implements SensorEventListener {

    private FragmentNotificationsBinding binding;
    View view;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        binding = FragmentNotificationsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        SensorManager sensorManager = (SensorManager) getActivity().getSystemService(Context.SENSOR_SERVICE);

        if(sensorManager != null){
            Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
            if (accelerometer != null){
                sensorManager.registerListener(this,accelerometer,SensorManager.SENSOR_DELAY_NORMAL);
            }
        } else {
            Toast.makeText(getContext(), "No Sensor", Toast.LENGTH_SHORT).show();
        }

        view = root;

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_GRAVITY){
            TextView textView = view.findViewById(R.id.Gr2);
            String ss = String.format("X: %s\nY: %s\nZ: %s", event.values[0], event.values[1], event.values[2]);
            textView.setText(ss);
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}