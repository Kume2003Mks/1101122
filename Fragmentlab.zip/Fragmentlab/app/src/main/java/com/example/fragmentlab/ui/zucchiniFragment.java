package com.example.fragmentlab.ui;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.fragmentlab.R;
import com.example.fragmentlab.databinding.FragmentDashboardBinding;

public class zucchiniFragment extends Fragment {

    private FragmentDashboardBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        zucchinidet(root);

        return root;
    }

    @SuppressLint("SetTextI18n")
    private void zucchinidet(View view) {
        TextView textView = view.findViewById(R.id.zucchini_det);
        textView.setTextSize(16);
        textView.setText("The zucchini or baby marrow is a summer squash, a vining herbaceous plant whose fruit are harvested when their immature seeds and epicarp (rind) are still soft and edible. It is closely related, but not identical, to the marrow; its fruit may be called marrow when mature.\n" +
                "\n" +
                "Golden zucchini grown in the Netherlands for sale in a supermarket in Montpellier, France, in April 2013\n" +
                "Ordinary zucchini fruit are any shade of green, though the golden zucchini is a deep yellow or orange. At maturity, they can grow to nearly 1 metre (3 feet) in length, but they are normally harvested at about 15–25 cm (6–10 in)");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}