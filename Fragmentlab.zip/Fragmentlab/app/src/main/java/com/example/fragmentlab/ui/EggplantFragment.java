package com.example.fragmentlab.ui;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.fragmentlab.R;
import com.example.fragmentlab.databinding.FragmentHomeBinding;

public class EggplantFragment extends Fragment {

    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        eggplantdet(root);

        return root;
    }

    @SuppressLint("SetTextI18n")
    private void eggplantdet(View view) {
        TextView textView = view.findViewById(R.id.eggplant_det);
        textView.setTextSize(16);
        textView.setText("Most commonly purple, the spongy," +
                " absorbent fruit is used in several cuisines." +
                " Typically used as a vegetable in cooking, it is a berry by botanical definition." +
                " As a member of the genus Solanum, it is related to the tomato, chili pepper, and potato," +
                " although those are of the New World while the eggplant is of the Old World. Like the tomato," +
                " its skin and seeds can be eaten, but, like the potato, it is usually eaten cooked." +
                " Eggplant is nutritionally low in macronutrient and micronutrient content," +
                " but the capability of the fruit to absorb oils and flavors into its flesh through cooking expands its use in the culinary arts.");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}