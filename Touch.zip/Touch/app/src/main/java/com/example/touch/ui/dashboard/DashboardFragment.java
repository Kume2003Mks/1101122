package com.example.touch.ui.dashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.touch.R;
import com.example.touch.databinding.FragmentDashboardBinding;

public class DashboardFragment extends Fragment {

    private FragmentDashboardBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        root.setOnTouchListener((v, event) -> {
            touch(event,root);
            return true;
        });

        return root;
    }

    private void touch(MotionEvent event, View root) {
        TextView textView1 = root.findViewById(R.id.M_1);
        TextView textView2 = root.findViewById(R.id.M_2);

        float x,y;
        int id;

        int pc = event.getPointerCount();

//        switch (evt){
//            case MotionEvent.ACTION_DOWN:
//
//                break;
//            case MotionEvent.ACTION_MOVE:
//                te = "Move";
//                break;
//            case MotionEvent.ACTION_UP:
//                te = "Up";
//                break;
//        }

        for (int i=0; i < pc ; i++){
            x = (float) event.getX(i);
            y = (float) event.getY(i);
            id = event.getPointerId(i);

            int evt = event.getActionMasked();
            String te = "Down";

            if(evt == MotionEvent.ACTION_DOWN){
                te = "Down";
            }else if (evt == MotionEvent.ACTION_UP){
                te = "Up";
            } else if (evt == MotionEvent.ACTION_MOVE){
                te = "Move";
            }

            String t = String.format("Pointer id %s Action: %s Action index %d\n" +
                    "X: %.2f Y: %.2f", id, te, pc, x, y);

            if (id == 0)
                textView1.setText(t);
            else
                textView2.setText(t);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}