package com.example.touch.ui.home;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.touch.R;
import com.example.touch.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    @SuppressLint("ClickableViewAccessibility")
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        root.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                touch(event, root);
                return true;
            }
        });
        return root;
    }

    private void touch(MotionEvent event, View root) {
        TextView textView = root.findViewById(R.id.S_1);

        float x,y;
        int id;

        int pc = event.getPointerCount();
        int evt = event.getActionMasked();
        String te = "";

        switch (evt){
            case MotionEvent.ACTION_DOWN:
                te = "Down";
                break;
            case MotionEvent.ACTION_MOVE:
                te = "Move";
                break;
            case MotionEvent.ACTION_UP:
                te = "Up";
                break;
            default:
                te = "  ";
                break;
        }

        for (int i=0; i < pc ; i++){
            x = (float) event.getX(i);
            y = (float) event.getY(i);
            id = event.getPointerId(i);



            String t = String.format("Pointer id 0 Action: %s Action index %d\n" +
                    "X: %.2f Y: %.2f", te, id, x, y);
            textView.setText(t);
        }

    }

        @Override
        public void onDestroyView () {
            super.onDestroyView();
            binding = null;
        }
    }