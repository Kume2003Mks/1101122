package com.example.animate;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        String ab = getString(R.string.st_id);
        actionBar.setTitle(ab);
    }

    public void Fade_In(View view) {
        YoYo.with(Techniques.FadeIn)
                .duration(1000)
                .repeat(5)
                .playOn(findViewById(R.id.textView0));
    }

    public void Fade_out(View view) {
        YoYo.with(Techniques.FadeOut)
                .duration(1000)
                .repeat(5)
                .playOn(findViewById(R.id.textView1));
    }

    public void cross_fade_out(View view) {
        YoYo.with(Techniques.FadeOutDown)
                .duration(1000)
                .repeat(5)
                .playOn(findViewById(R.id.textView2));
    }

    public void blink(View view) {
        YoYo.with(Techniques.Flash)
                .duration(1000)
                .repeat(5)
                .playOn(findViewById(R.id.textView3));
    }

    public void zoomin(View view) {
        YoYo.with(Techniques.StandUp)
                .duration(1000)
                .repeat(5)
                .playOn(findViewById(R.id.textView4));
        TextView tw = findViewById(R.id.textView4);
        tw.setTextSize(40);
    }

    public void zoomout(View view) {
        YoYo.with(Techniques.FadeOut)
                .duration(1000)
                .repeat(5)
                .playOn(findViewById(R.id.textView5));
        TextView tw = findViewById(R.id.textView5);
        tw.setTextSize(2);
    }

    public void rotate(View view) {
        YoYo.with(Techniques.RotateInDownRight)
                .duration(1000)
                .repeat(5)
                .playOn(findViewById(R.id.textView6));
    }

    public void move(View view) {
        YoYo.with(Techniques.SlideOutRight)
                .duration(1000)
                .repeat(5)
                .playOn(findViewById(R.id.textView7));
    }

    public void slideup(View view) {
        YoYo.with(Techniques.SlideInUp)
                .duration(1000)
                .repeat(5)
                .playOn(findViewById(R.id.textView8));
    }

    public void slidedown(View view) {
        YoYo.with(Techniques.SlideInDown)
                .duration(1000)
                .repeat(5)
                .playOn(findViewById(R.id.textView9));
    }

    public void bounce(View view) {
        YoYo.with(Techniques.Bounce)
                .duration(1000)
                .repeat(5)
                .playOn(findViewById(R.id.textView10));
    }

    public void Sequential(View view) {
        YoYo.with(Techniques.Swing)
                .duration(1000)
                .repeat(5)
                .playOn(findViewById(R.id.textView11));
    }

    public void Together(View view) {
        TextView tw = findViewById(R.id.textView12);
        tw.setTextSize(40);
        YoYo.with(Techniques.FlipOutX)
                .duration(1000)
                .repeat(5)
                .playOn(findViewById(R.id.textView12));
    }

    public void p2(View view) {
        startActivity(new Intent(this,MainActivity2.class));
    }
}